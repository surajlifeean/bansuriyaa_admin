<!-- <?php echo e(dump($subproduct)); ?>

 -->


<?php $__env->startSection('title','|Homepage'); ?>

			


<?php $__env->startSection('content'); ?>


<div class="col-md-10 content">
  <div class="panel panel-default">
 	 <div class="panel-heading">
    	All Subproducts
  	</div>
  	<div class="panel-body">
  			<table class="table table-striped">
 					
  			<thead>
  			<tr>
  			<th>Product Name</th>
  			<th>product code</th>
  			<th>price</th>
  			<th>quantity</th>
  			<th>Discount</th>
  			<th>attribute</th>
  			<th>Image</th>
  			<th>Actions</th>

  			
  			
  			</tr>
  			</thead>
 					<tbody>

 						<?php $__currentLoopData = $subproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
							<tr>
							<td>
							<?php echo e($item->product->name); ?>

							</td>
							<td>		
							<?php echo e($item->pcode); ?>

							</td>
							<td>
							<?php echo e($item->price); ?>

							</td>
							<td>
							<?php echo e($item->quantity); ?>

							</td>
							<td>
							<?php echo e($item->discount); ?>

							<?php if($item->discount_type=='Flat'): ?>
							 Flat
							<?php else: ?>
							%
							<?php endif; ?>
							</td>
							<td>
							<?php echo e($item->getsize->name); ?>

							<?php echo e($item->getcolor->color); ?>

							
							<div style="width:10px;height:10px;border:5px solid <?php echo e($item->getcolor->color_code); ?>;">
							</div>

							</td>
							<td>
							<?php 
							$img=$item->images[0]->name
							 ?>
							<img src="<?php echo e(asset('images/'.$img)); ?>" height="160px" weight="120px">
								
							</td>
							<td>
							<?php if($item->status==1): ?>
							<button type="button" class="btn btn-default active" aria-label="Left Align">
								 <span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span>
							</button>
							<?php else: ?>
							<button type="button" class="btn btn-default inactive" aria-label="Left Align">
								 <span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span>
							</button>

							<?php endif; ?>

                 <?php echo Html::LinkRoute('productimage.edit','',array($item->id),array('class'=>"btn btn-primary glyphicon glyphicon-picture")); ?>

						

                 <?php echo Html::LinkRoute('subproduct.edit','',array($item->id),array('class'=>"btn btn-primary glyphicon glyphicon-pencil")); ?>

							
							<button type="button" class="btn btn-default" aria-label="Left Align">
								 <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
							</button>
							</td>
							
							</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>

			</table>

  		</div>
	</div>
 </div>
		  <footer class="pull-left footer">
        <p class="col-md-12">
          <hr class="divider">
          Powered By 2017 <a href="http://www.pingpong-labs.com">, AIDA</a>
        </p>
      </footer>
    </div>

  <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	$(".inactive").click(function(){

		confirm("Do you want to make it Active?");

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>