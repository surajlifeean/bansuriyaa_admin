<?php $__env->startSection('title','|Homepage'); ?>



<?php $__env->startSection('content'); ?>


      <div class="col-md-10 content">
          <div class="panel panel-default">
  <div class="panel-heading">
    Edit Product
  </div>
  <div class="panel-body">

    <?php echo Form::model($category,['route'=>['category.update',$category->id],'method'=>'PUT']); ?>



		<?php echo e(Form::label('title','Title:')); ?>

		<?php echo e(Form::text('title',null,array('class'=>'form-control'))); ?>



		<?php echo e(Form::label('description','Description:')); ?>

		<?php echo e(Form::text('description',null,array('class'=>'form-control'))); ?>

	
		<?php echo e(Form::label('status','Select Status:')); ?>

		
		<?php if($category->status==1): ?>
			Active
		<?php else: ?> 
			Inactive
		<?php endif; ?>

		<?php echo e(Form::select('status', ['0' => 'inactive', '1' => 'active'], null, ['placeholder' => 'Pick a Category...'],array('class'=>'form-control btn btn-primary'))); ?>



	
		<?php echo e(Form::submit('Save Changes',array('class'=>'form-control btn btn-primary'))); ?>

  <?php echo Form::close(); ?>



  </div>
</div>
      </div>
      <footer class="pull-left footer">
        <p class="col-md-12">
          <hr class="divider">
          Powered By 2017 <a href="http://www.pingpong-labs.com">, AIDA</a>
        </p>
      </footer>
    </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>