<?php $__env->startSection('title','|Homepage'); ?>



<?php $__env->startSection('content'); ?>


<div class="col-md-10 content">
  <div class="panel panel-default">
 	 <div class="panel-heading">
    	All Products
  	</div>
  	<div class="panel-body">
  			<table class="table table-striped">
 					
  			<thead>
  			<tr>
  			<th>Product Name</th>
  			<th>Category</th>
  			<th>Action</th>
  			</tr>
  			</thead>
 					<tbody>

 						<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
							<tr><td>
							<?php echo e($item->name); ?>

							</td>
							<td><?php echo e($item->categories->title); ?>>><?php echo e($item->subcategory->name); ?>

							</td>

							<td>

							<?php if($item->status==1): ?>
							<button type="button" class="btn btn-default active" aria-label="Left Align">
								 <span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span>
							</button>
							<?php else: ?>
							<button type="button" class="btn btn-default inactive" aria-label="Left Align">
								 <span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span>
							</button>

							<?php endif; ?>

							<button type="button" class="btn btn-default" aria-label="Left Align">
								 <span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span>
							</button>


                 <?php echo Html::LinkRoute('product.edit','',array($item->id),array('class'=>"btn btn-primary glyphicon glyphicon-pencil")); ?>

							
							<button type="button" class="btn btn-default" aria-label="Left Align">
								 <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
							</button>
							</td>
							
							</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>

			</table>

  		</div>
	</div>
 </div>
		  <footer class="pull-left footer">
        <p class="col-md-12">
          <hr class="divider">
          Powered By 2017 <a href="http://www.pingpong-labs.com">, AIDA</a>
        </p>
      </footer>
    </div>

  <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	$(".inactive").click(function(){

		confirm("Do you want to make it Active?");

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>