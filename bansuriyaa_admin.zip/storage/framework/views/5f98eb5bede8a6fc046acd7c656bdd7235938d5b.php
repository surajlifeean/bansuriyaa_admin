<?php $__env->startSection('stylesheets'); ?>

<style>
	.check
{
    opacity:0.5;
	color:#996;
	
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

		
<div class="container">
	<div class="row">

<?php echo Form::model($imagename,['route'=>['productimage.update',$imagename->id, 'files' => true], 'method'=>'PUT']); ?>



		<div class="form-group">	


		<?php $__currentLoopData = $imagename; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


		<div class="col-md-3"> <label class="btn btn-primary"><img src="<?php echo e(asset('images/'.$image->name)); ?>" class="img-thumbnail img-check"> <input type="file" name="chk[]" id="item[]" value="<?php echo e($image->name); ?>" autocomplete="off"></label>
		</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>

		<input type="Submit" value="Submit" class="btn btn-success">
		
	  <?php echo Form::close(); ?>



	</div>	
</div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<script>
	$('.form-group').click(function(e){
    			
			alert (image.input[1].value);

    		});
	});


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>