<!-- <?php echo e(dump($subproduct)); ?> -->




<?php $__env->startSection('title','|add Subproduct'); ?>



<?php $__env->startSection('content'); ?>


      <div class="col-md-10 content">
          <div class="panel panel-default">
  <div class="panel-heading">
    Edit Subproduct
  </div>
  <div class="panel-body">

    <?php echo Form::model($subproduct,['route'=>['subproduct.update',$subproduct->id],'method'=>'PUT']); ?>




    <?php echo e(Form::label('product_id','Select Product:')); ?>


    <?php echo e(Form::select('product_id',$products,$subproduct->product_id,['class'=>'form-control'])); ?>



    <?php echo e(Form::label('color_id','Select Color:')); ?>


    <?php echo e(Form::select('color_id',$colors,$subproduct->color,['class'=>'form-control'])); ?>



    <?php echo e(Form::label('size_id','Select Size:')); ?>


    <?php echo e(Form::select('size_id',$sizes,$subproduct->size,['class'=>'form-control'])); ?>




		<?php echo e(Form::label('pcode','Product Code:')); ?>

		<?php echo e(Form::text('pcode',null,array('class'=>'form-control'))); ?>


	<div class="row">
		<div class="col-md-3">
		<?php echo e(Form::label('quantity','Qty:')); ?>

		<?php echo e(Form::text('quantity',null,array('class'=>'form-control'))); ?>

		</div>

		<div class="col-md-3">
		<?php echo e(Form::label('price','Price:')); ?>

		<?php echo e(Form::text('price',null,array('class'=>'form-control'))); ?>

		</div>
		
		<div class="col-md-3">
		<?php echo e(Form::label('discount','Discount Value:')); ?>

		<?php echo e(Form::text('discount',null,array('class'=>'form-control'))); ?>

		</div>
		

		<div class="col-md-3">
		
		<?php echo e(Form::label('distype','Discount Type:')); ?> <br>


Percentage:<input type="radio" name="distype" value="Percentage" <?php if($subproduct->discount_type=='Percentage'): ?> checked <?php endif; ?>}}>
Flat:<input type="radio" name="distype" value="Flat" <?php if($subproduct->discount_type=='Flat'): ?> checked <?php endif; ?>}}>


		</div>

	</div>
	<!-- <br>
	
		<?php echo e(Form::label('image','Main Image')); ?>

		
	
	<br>

<div class="input_fields_wrap">
    <button class="add_field_button glyphicon glyphicon-plus btn btn-primary" aria-hidden="true">Add More Images</button><br>
    <div>
    		 <input type="file" name="image[]"> 
    </div>
</div>
 -->
<br>
<br>
		<?php echo e(Form::submit('Submit',array('class'=>'form-control btn btn-primary'))); ?>

  <?php echo Form::close(); ?>



  </div>
</div>
      </div>
      <footer class="pull-left footer">
        <p class="col-md-12">
          <hr class="divider">
          Powered By 2017 <a href="http://www.pingpong-labs.com">, AIDA</a>
        </p>
      </footer>
    </div>

  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>

<script>
  

  	$(document).ready(function() {
    var max_fields      = 5; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div><input type="file" name="image[]"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>