<?php if(Session::has('success')): ?>
	
	<div class="alert alert-success" role="alert">

		<strong>Success:</strong><?php echo e(Session::get('success')); ?>

	</div>
	
<?php endif; ?>