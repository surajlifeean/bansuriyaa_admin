<?php $__env->startSection('title','|Create Product'); ?>



<?php $__env->startSection('content'); ?>


      <div class="col-md-10 content">
          <div class="panel panel-default">
  <div class="panel-heading">
    Add Product
  </div>
  <div class="panel-body">

    <?php echo Form::open(array('route'=>'product.store')); ?>




		<?php echo e(Form::label('title','Title:')); ?>

		<?php echo e(Form::text('title',null,array('class'=>'form-control'))); ?>



		<?php echo e(Form::label('description','Description:')); ?>

		<?php echo e(Form::text('description',null,array('class'=>'form-control'))); ?>

	<br>
	<div class="row">
		
		<div class="col-md-6">
				<?php echo e(Form::label('category','Select Category:')); ?>   
				<?php echo e(Form::select('category',$categories,null,['class'=>'form-control category'])); ?>


		</div>
		

		<div class="col-md-6">

				<?php echo e(Form::label('subcategory','Select Subcategory:')); ?>


				 <select class="form-control subcategory" name="subcategory">
  
    </select>

		</div>
	</div>

	
		<?php echo e(Form::submit('Submit',array('class'=>'form-control btn btn-primary'))); ?>

  <?php echo Form::close(); ?>



  </div>
</div>
      </div>
      <footer class="pull-left footer">
        <p class="col-md-12">
          <hr class="divider">
          Powered By 2017 <a href="http://www.pingpong-labs.com">, AIDA</a>
        </p>
      </footer>
    </div>


  <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
		<script>

				$('.category').on('change',function(e){

					var cat_id=e.target.value;

					console.log(cat_id);
		$(".subcategory").empty();
			$.ajax({
               type:'GET',
               url:'/ajaxreq/create',
               data:{cat_id:cat_id},
               success:function(data){
                console.log(data);
                $.each(data,function(index,data){
                   $('.subcategory').append('<option value="'+data.id+'">'+data.name+'</option>');
                 });
                 
               }
            });



});

		</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>