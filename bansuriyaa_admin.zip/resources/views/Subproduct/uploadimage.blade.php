@extends('main')


@section('stylesheets')

<style>
	.check
{
    opacity:0.5;
	color:#996;
	
}

</style>

@endsection

@section('content')

		
<div class="container">
	<div class="row">

{!!Form::model($imagename,['route'=>['productimage.update',$imagename->id, 'files' => true], 'method'=>'PUT'])!!}


		<div class="form-group">	


		@foreach($imagename as $image)


		<div class="col-md-3"> <label class="btn btn-primary"><img src="{{asset('images/'.$image->name)}}" class="img-thumbnail img-check"> <input type="file" name="chk[]" id="item[]" value="{{$image->name}}" autocomplete="off"></label>
		</div>

		@endforeach

		</div>

		<input type="Submit" value="Submit" class="btn btn-success">
		
	  {!!Form::close()!!}


	</div>	
</div>




@endsection



@section('scripts')

<script>
	$('.form-group').click(function(e){
    			
			alert (image.input[1].value);

    		});
	});


</script>


@endsection