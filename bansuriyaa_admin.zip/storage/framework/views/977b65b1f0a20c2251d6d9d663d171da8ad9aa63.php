<?php $__env->startSection('title','|Create Size'); ?>


<?php $__env->startSection('stylesheets'); ?>
	
	<?php echo Html::style('css/jquery.minicolors.css'); ?>


	
  <link rel="shortcut icon" href="http://www.templatemonster.com/favicon.ico">
  <link rel="icon" href="http://www.templatemonster.com/favicon.ico">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <div class="panel-heading">
    Add Size
  </div>
    
      <div class="row">
      <?php echo Form::open(array('route'=>'size.store')); ?>


     	  <div class="col-md-6">

			    <?php echo e(Form::label('name','Size Name:')); ?>

					<?php echo e(Form::text('name',null,array('class'=>'form-control'))); ?>



          <?php echo e(Form::label('description','Description:')); ?>

          <?php echo e(Form::text('description',null,array('class'=>'form-control'))); ?>



					<?php echo e(Form::submit('Submit',array('class'=>'form-control btn btn-primary'))); ?>

				  <?php echo Form::close(); ?>


			  </div>
			  			      
      </div><!-- @end  .row -->
  
 




<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>