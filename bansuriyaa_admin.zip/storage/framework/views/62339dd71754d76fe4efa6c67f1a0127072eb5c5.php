<?php $__env->startSection('title','|Create Category'); ?>



<?php $__env->startSection('content'); ?>


  <div class="col-md-10 content">
          <div class="panel panel-default">
  <div class="panel-heading">
    Add SubCategory
  </div>
  <div class="panel-body">

    <?php echo Form::model($subcategory,array('route'=>['subcategory.update',$subcategory->id],'method'=>'PUT')); ?>





		<?php echo e(Form::label('name','Category Name:')); ?>

		<?php echo e(Form::text('name',null,array('class'=>'form-control'))); ?>



		<?php echo e(Form::label('description','Description:')); ?>

		<?php echo e(Form::text('description',null,array('class'=>'form-control'))); ?>

	
	 
    <?php echo e(Form::label('category_id','Select Main Category:')); ?>


    <?php echo e(Form::select('category_id',$categories,$subcategory->category_id,['class'=>'form-control'])); ?>


		<?php echo e(Form::submit('Submit',array('class'=>'form-control btn btn-primary'))); ?>

  <?php echo Form::close(); ?>



  </div>
</div>
      </div>
      <footer class="pull-left footer">
        <p class="col-md-12">
          <hr class="divider">
          Powered By 2017 <a href="http://www.pingpong-labs.com">, AIDA</a>
        </p>
      </footer>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>