<?php $__env->startSection('title','|Create Color'); ?>


<?php $__env->startSection('stylesheets'); ?>
	
	<?php echo Html::style('css/jquery.minicolors.css'); ?>


	
  <link rel="shortcut icon" href="http://www.templatemonster.com/favicon.ico">
  <link rel="icon" href="http://www.templatemonster.com/favicon.ico">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <div class="panel-heading">
    Add Color
  </div>
    
      <div class="row">
      <?php echo Form::open(array('route'=>'color.store')); ?>


     	  <div class="col-md-6">

			        <?php echo e(Form::label('name','Color Name:')); ?>

					<?php echo e(Form::text('name',null,array('class'=>'form-control'))); ?>


					<?php echo e(Form::label('color_code','Color:')); ?><br>
					  <input type="text" id="inlinecolors" class="form-control" data-inline="true" value="#4fc8db" name="color_code">
			 </div>
			  
			  
			  <div id="inlinecolorhex" class="col-md-6">
			    <h3>Current selection: <small>#4fc8db</small></h3>
					<?php echo e(Form::submit('Submit',array('class'=>'form-control btn btn-primary'))); ?>

				  <?php echo Form::close(); ?>


			  </div>
			  			      
      </div><!-- @end  .row -->
  
 




<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php echo Html::script('js/jquery.minicolors.min.js'); ?>

	
<script type="text/javascript">
$(function(){
  
  var $inlinehex = $('#inlinecolorhex h3 small');
  $('#inlinecolors').minicolors({
    inline: true,
    theme: 'bootstrap',
    change: function(hex) {
      if(!hex) return;
      $inlinehex.html(hex);
    }
  });
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>